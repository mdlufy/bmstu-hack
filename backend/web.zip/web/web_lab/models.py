from django.db import models
from django.contrib.auth import models as user_models
from django.contrib.auth.models import PermissionsMixin, UserManager


class user(user_models.AbstractBaseUser, PermissionsMixin):
    id= models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    username=models.CharField(max_length=150)
    password=models.CharField(max_length=128, verbose_name='password')
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    is_staff=models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()

    class Meta:
        managed = False
        db_table = 'auth_user'


class posts(models.Model):
    id = models.BigAutoField(primary_key=True)
    user_id = models.IntegerField()
    text = models.CharField(max_length=255)
    post_date = models.DateField()

    class Meta:
        managed = False
        db_table = 'posts'


class likes(models.Model):
    id = models.BigAutoField(primary_key=True)
    user_id = models.IntegerField()
    post_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'likes'


class subscriptions(models.Model):
    id = models.BigAutoField(primary_key=True)
    subscribed_user_id = models.IntegerField()
    subscription_user_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'subscriptions'
