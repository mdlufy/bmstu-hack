from web_lab.models import posts, user, likes, subscriptions
from rest_framework import serializers

class postSerializer(serializers.ModelSerializer):
    class Meta:
        # Модель, которую мы сериализуем
        model = posts
        # Поля, которые мы сериализуем
        fields = ["id", "user_id", "text", "post_date"]

class userSerializer(serializers.ModelSerializer):
    class Meta:
        # Модель, которую мы сериализуем
        model = user
        # Поля, которые мы сериализуем
        fields = ["id", "first_name","last_name", "email", "username", "password", "date_joined"]

class likeSerializer(serializers.ModelSerializer):
    class Meta:
        # Модель, которую мы сериализуем
        model = likes
        # Поля, которые мы сериализуем
        fields = ["id", "user_id", "post_id"]

class subscriptionSerializer(serializers.ModelSerializer):
    class Meta:
        # Модель, которую мы сериализуем
        model = subscriptions
        # Поля, которые мы сериализуем
        fields = ["id", "subscribed_user_id", "subscription_user_id"]