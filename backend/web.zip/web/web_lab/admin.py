from django.contrib import admin
from .models import user, subscriptions, likes, posts

admin.site.register(user)
admin.site.register(posts)
admin.site.register(subscriptions)
admin.site.register(likes)
