import json

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets, status
from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser

from web_lab.serializers import postSerializer, userSerializer, likeSerializer, subscriptionSerializer
from web_lab.models import posts, user, likes, subscriptions

from django.contrib.auth import authenticate, login
from django.http import HttpResponse, JsonResponse
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.conf import settings
import redis
import uuid

# Connect to our Redis instance
session_storage = redis.StrictRedis(host=settings.REDIS_HOST, port=settings.REDIS_PORT)

class ExampleView(APIView):
    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        content = {
            'user': str(request.user),  # `django.contrib.auth.User` instance.
            'auth': str(request.auth),  # None
        }
        return Response(content)

@csrf_exempt
def auth_view(request):

    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    email = body['email']
    password = body['password']
    account = authenticate(request, email=email, password=password)

    if account is not None:
        random_key = uuid.uuid4()
        print(random_key)
        random_key=str(random_key)
        session_storage.set(random_key, email)
        response = HttpResponse('{"status": "ok"}')
        response.set_cookie('session_id', random_key)
        return response
    else:
        return HttpResponse('{"status": "error", "error": "login failed"}')


def GetUsers(request):
    return render(request, 'users.html', {'data': {
        'users': [
            {'name': 'aasas', 'id': 1, 'passwd': 'a'},
            {'name': 'slvlm', 'id': 2, 'passwd': 'x'},
            {'name': 'Кsvs', 'id': 3, 'passwd': 'aaa'},
        ]
    }})


def GetUser(request, id):
    return render(request, 'user.html', {'data': {
        'id': id,
    }})

def postsList(request):
    return render(request, 'posts.html', {'data' : {
        'posts': posts.objects.all()
    }})

def Getpost(request, id):
    return render(request, 'post.html', {'data' : {
        'post': posts.objects.filter(id=id)[0]
    }})

class postViewSet(viewsets.ModelViewSet):
    # queryset всех пользователей для фильтрации по дате последнего изменения
    queryset = posts.objects.all()
    serializer_class = postSerializer  # Сериализатор для модели

class userViewSet(viewsets.ModelViewSet):
    # queryset всех пользователей для фильтрации по дате последнего изменения
    queryset = user.objects.all()
    serializer_class = userSerializer  # Сериализатор для модели

class likeViewSet(viewsets.ModelViewSet):
    # queryset всех пользователей для фильтрации по дате последнего изменения
    queryset = likes.objects.all()
    serializer_class = likeSerializer  # Сериализатор для модели

class subscriptionViewSet(viewsets.ModelViewSet):
    queryset = subscriptions.objects.all()
    serializer_class = subscriptionSerializer


@api_view(['GET', 'POST', 'DELETE'])
def posts_list(request):
    if request.method == 'GET':
        ssid = request.COOKIES["session_id"]
        text=session_storage.get(ssid)
        post = posts.objects.all()
        title = request.query_params.get('title', None)
        if title is not None:
            post = posts.filter(title__icontains=title)
        posts_serializer = postSerializer(post, many=True)
        return JsonResponse(posts_serializer.data, safe=False,)
        # 'safe=False' for objects serialization

    elif request.method == 'POST':
        post_data = JSONParser().parse(request)
        posts_serializer = postSerializer(data=post_data)
        if posts_serializer.is_valid():
            posts_serializer.save()
            return JsonResponse(posts_serializer.data, status=status.HTTP_201_CREATED, )
        return JsonResponse(posts_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
