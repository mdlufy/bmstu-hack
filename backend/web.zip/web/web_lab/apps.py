from django.apps import AppConfig


class WebLabConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'web_lab'
