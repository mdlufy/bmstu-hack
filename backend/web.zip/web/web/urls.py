from django.contrib import admin
from django.template.defaulttags import url
from web_lab import views as blogs_views, views
from django.urls import include, path
from rest_framework import routers

router = routers.DefaultRouter()
router.register('posts', blogs_views.postViewSet)
router.register('users', blogs_views.userViewSet)
router.register('likes', blogs_views.likeViewSet)
router.register('subscriptions', blogs_views.subscriptionViewSet)

# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
urlpatterns = [
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    path('admin/', admin.site.urls),
    path('postslist', views.postsList),
    path('postslist/<int:id>/', views.Getpost, name='post_url'),
    path('userlist', views.GetUsers),
    path('userlist/<int:id>/', views.GetUser, name='user_url'),
    path('authorize/', views.auth_view),
    path('posts', views.posts_list)
]
